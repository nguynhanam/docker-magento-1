PASS=$(openssl rand -hex 16)
EXPOSE $sslPath
cd $sslPath 
openssl genrsa -des3 -passout pass:$PASS -out server.pass.key 2048 
openssl rsa -passin pass:$PASS -in server.pass.key -out server.key
rm server.pass.key
openssl req -new -key server.key -out server.csr -subj "/C=UK/ST=Warwickshire/L=Leamington/O=OrgName/OU=IT Department/CN=netpower.no"
openssl x509 -req -days 365 -in server.csr -signkey server.key -out server.crt
