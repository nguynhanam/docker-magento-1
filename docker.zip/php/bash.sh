git clone $gitRepository
